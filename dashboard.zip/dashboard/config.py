# dashboard/config.py

API_URL = "http://localhost:8000"
