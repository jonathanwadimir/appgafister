# dashboard/utils/auth.py

import requests
from dashboard.config import API_URL

def login(username: str, password: str) -> str | None:
    try:
        response = requests.post(
            f"{API_URL}/auth/login",
            data={"username": username, "password": password}
        )
        if response.status_code == 200:
            return response.json().get("access_token")
    except Exception as e:
        print(f"[login] Error: {e}")
    return None

def get_current_user(token: str) -> dict | None:
    try:
        headers = {"Authorization": f"Bearer {token}"}
        response = requests.get(f"{API_URL}/users/me", headers=headers)
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        print(f"[get_current_user] Error: {e}")
    return None
